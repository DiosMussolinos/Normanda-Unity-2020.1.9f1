package com.example.freshexample.com.example.normanda_capp

class Global {
    companion object{
        var id:Int = 0;
    }


}