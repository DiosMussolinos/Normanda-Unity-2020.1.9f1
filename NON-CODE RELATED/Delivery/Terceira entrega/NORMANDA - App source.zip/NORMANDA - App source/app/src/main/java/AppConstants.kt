package com.example.freshexample

class AppConstants{
    companion object{
        const val ACTION_STOP = "stop"
        const val ACTION_START = "start"

    }

}