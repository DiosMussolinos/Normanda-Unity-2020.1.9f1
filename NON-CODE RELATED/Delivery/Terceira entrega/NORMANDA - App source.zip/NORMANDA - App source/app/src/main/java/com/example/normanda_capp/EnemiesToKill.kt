package com.example.freshexample.com.example.normanda_capp

class EnemiesToKill {
    companion object{
        var EnemiesToKillToAct:Int = 0;

    }
}