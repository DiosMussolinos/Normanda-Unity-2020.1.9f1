package com.example.freshexample

data class Items(val Image:Int, val name:String, val cost:String, val stat:String, val lore:String, val bag:Int) {

}